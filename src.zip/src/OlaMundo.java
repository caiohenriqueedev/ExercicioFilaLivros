
public class OlaMundo {
    
    public static void main(String[]args){
        System.out.print("Bom dia!");
        System.out.println("Boa Noite!");
        
    }
}
