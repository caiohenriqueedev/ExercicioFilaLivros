
public class Variavelpontoflutuante {
    public static void main(String[]args){
        double x = 10.39856;
        System.out.println(x);
        System.out.printf("%.2f%n", x);
        System.out.printf("%.4f%n", x);
    }
}
