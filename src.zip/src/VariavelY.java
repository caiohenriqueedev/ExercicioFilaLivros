
public class VariavelY {
     public static void main(String[]args){
         int y = 35;
         System.out.println(y);
     }
}
