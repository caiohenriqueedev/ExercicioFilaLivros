
public class concatenacao {
    public static void main(String[]args){
        double x = 10.98546;
      System.out.println("RESULTADO = " + x + " METROS");
      System.out.printf("RESULTADO = %.1f metros%n", x);
      //%f = ponto flutuante
      //%n = quebra de linha
      

    }
}
